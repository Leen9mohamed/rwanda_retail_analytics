# Hardcopy report – order of contents
1. Cover page (ULK, course, assignment, group no., names of PRESENT members only)
2. Introduction + business problem (README §2–3)   3. Objectives (README §4)
4. Database design + ERD (documentation/ERD.png)   5. Full CREATE TABLE (01_create_tables.sql) + constraints (03)
6. Full INSERT scripts (02_insert_data.sql)         7. 5 JOIN queries (01–05) + screenshot + explanation + 2–3 sentence interpretation each
8. Window functions (06–09) + screenshot + explanation each   9. Descriptive / Diagnostic / Prescriptive analysis (README §10)
10. References   11. Public GitHub link
