-- =====================================================================
-- 09_distribution_functions.sql | NTILE(4) and CUME_DIST()
-- =====================================================================

-- Q1. [Objective 4] Segment customers into 4 spending groups with NTILE(4).
WITH spend AS (
    SELECT c.customer_id, c.full_name, SUM(s.total_amount) AS total_spent
    FROM customers c INNER JOIN sales s ON c.customer_id = s.customer_id
    GROUP BY c.customer_id, c.full_name
)
SELECT full_name, total_spent,
       NTILE(4) OVER (ORDER BY total_spent DESC) AS quartile,
       CASE NTILE(4) OVER (ORDER BY total_spent DESC)
            WHEN 1 THEN 'Platinum' WHEN 2 THEN 'Gold' WHEN 3 THEN 'Silver' ELSE 'Bronze'
       END AS segment
FROM spend
ORDER BY total_spent DESC;

-- Q2. Segment sales employees by performance (NTILE(4) on revenue).
WITH emp AS (
    SELECT e.full_name, COALESCE(SUM(s.total_amount), 0) AS revenue
    FROM employees e LEFT JOIN sales s ON e.employee_id = s.employee_id
    WHERE e.job_title = 'Sales Representative'
    GROUP BY e.full_name
)
SELECT full_name, revenue,
       NTILE(4) OVER (ORDER BY revenue DESC) AS performance_group
FROM emp ORDER BY revenue DESC;

-- Q3. Cumulative distribution of product revenue (CUME_DIST = share of products with revenue <= current).
WITH prod AS (
    SELECT p.product_name, SUM(s.total_amount) AS revenue
    FROM products p INNER JOIN sales s ON p.product_id = s.product_id
    GROUP BY p.product_name
)
SELECT product_name, revenue,
       ROUND(CAST(CUME_DIST()    OVER (ORDER BY revenue) AS NUMERIC), 3) AS cume_dist,
       ROUND(CAST(PERCENT_RANK() OVER (ORDER BY revenue) AS NUMERIC), 3) AS pct_rank
FROM prod ORDER BY revenue;

-- Q4. Distribution of customer purchasing behaviour (number of purchases per customer).
WITH freq AS (
    SELECT c.full_name, COUNT(s.sale_id) AS purchases, SUM(s.total_amount) AS total_spent
    FROM customers c INNER JOIN sales s ON c.customer_id = s.customer_id
    GROUP BY c.full_name
)
SELECT full_name, purchases, total_spent,
       ROUND(CAST(CUME_DIST() OVER (ORDER BY purchases) AS NUMERIC), 3) AS cume_dist_purchases,
       NTILE(4) OVER (ORDER BY purchases DESC) AS frequency_quartile
FROM freq ORDER BY purchases DESC, total_spent DESC;
