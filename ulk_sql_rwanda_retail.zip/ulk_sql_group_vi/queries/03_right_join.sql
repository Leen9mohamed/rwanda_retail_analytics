-- =====================================================================
-- 03_right_join.sql  |  RIGHT JOIN: all rows from the RIGHT table + matches from the left
-- =====================================================================

-- Q1. Customers who have NEVER purchased (right = customers).
SELECT c.customer_id, c.full_name, c.join_date
FROM sales s
RIGHT JOIN customers c ON s.customer_id = c.customer_id
WHERE s.sale_id IS NULL;

-- Q2. Equivalent approach (for DBMS without RIGHT JOIN): swap table order and use LEFT JOIN.
SELECT c.customer_id, c.full_name, c.join_date
FROM customers c
LEFT JOIN sales s ON s.customer_id = c.customer_id
WHERE s.sale_id IS NULL;

-- Q3. Number of purchases per customer, including customers with 0 purchases.
SELECT c.customer_id, c.full_name, COUNT(s.sale_id) AS purchases
FROM sales s
RIGHT JOIN customers c ON s.customer_id = c.customer_id
GROUP BY c.customer_id, c.full_name
ORDER BY purchases, c.customer_id;
