-- =====================================================================
-- 04_full_outer_join.sql  |  FULL OUTER JOIN: matched + unmatched rows from BOTH tables
-- Supported natively by PostgreSQL / SQLite 3.39+ / SQL Server.
-- MySQL has NO FULL OUTER JOIN -> use the UNION equivalent in Q2.
-- =====================================================================

-- Q1. Customers vs sales: shows customers with no sales AND sales with no customer (walk-ins).
SELECT c.customer_id,
       c.full_name,
       s.sale_id,
       s.total_amount,
       CASE
            WHEN s.sale_id     IS NULL THEN 'Customer without purchases'
            WHEN c.customer_id IS NULL THEN 'Walk-in sale (no customer record)'
            ELSE 'Matched'
       END AS match_status
FROM customers c
FULL OUTER JOIN sales s ON c.customer_id = s.customer_id
WHERE s.sale_id IS NULL OR c.customer_id IS NULL
ORDER BY match_status, s.sale_id;

-- Q2. MySQL-compatible equivalent: LEFT JOIN UNION RIGHT JOIN.
SELECT c.customer_id, c.full_name, s.sale_id, s.total_amount
FROM customers c LEFT JOIN sales s ON c.customer_id = s.customer_id
WHERE s.sale_id IS NULL
UNION
SELECT c.customer_id, c.full_name, s.sale_id, s.total_amount
FROM customers c RIGHT JOIN sales s ON c.customer_id = s.customer_id
WHERE c.customer_id IS NULL;
