-- =====================================================================
-- 01_inner_join.sql  |  INNER JOIN: only rows that match in ALL joined tables
-- =====================================================================

-- Q1. Full sales report: who bought what, where, and who sold it.
-- Walk-in sales (customer_id IS NULL) are automatically EXCLUDED by INNER JOIN.
SELECT s.sale_id,
       s.sale_date,
       c.full_name     AS customer,
       p.product_name,
       b.branch_name,
       r.region_name,
       e.full_name     AS sold_by,
       s.quantity,
       s.total_amount
FROM sales s
INNER JOIN customers c ON s.customer_id = c.customer_id
INNER JOIN products  p ON s.product_id  = p.product_id
INNER JOIN branches  b ON s.branch_id   = b.branch_id
INNER JOIN regions   r ON b.region_id   = r.region_id
INNER JOIN employees e ON s.employee_id = e.employee_id
ORDER BY s.sale_id
LIMIT 15;

-- Q2. Revenue by region (INNER JOIN + GROUP BY).
SELECT r.region_name,
       COUNT(s.sale_id)    AS transactions,
       SUM(s.total_amount) AS total_revenue
FROM sales s
INNER JOIN branches b ON s.branch_id = b.branch_id
INNER JOIN regions  r ON b.region_id = r.region_id
GROUP BY r.region_name
ORDER BY total_revenue DESC;
