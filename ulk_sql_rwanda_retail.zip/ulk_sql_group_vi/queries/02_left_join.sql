-- =====================================================================
-- 02_left_join.sql  |  LEFT JOIN: all rows from the LEFT table + matches from the right
-- Use "WHERE right_key IS NULL" to find left rows WITHOUT a match.
-- =====================================================================

-- Q1. Products that have NEVER been sold (left = products).
SELECT p.product_id, p.product_name, p.category, p.unit_price
FROM products p
LEFT JOIN sales s ON p.product_id = s.product_id
WHERE s.sale_id IS NULL;

-- Q2. Branches with NO sales (left = branches).
SELECT b.branch_id, b.branch_name, r.region_name
FROM branches b
INNER JOIN regions r ON b.region_id = r.region_id
LEFT JOIN  sales   s ON b.branch_id = s.branch_id
WHERE s.sale_id IS NULL;

-- Q3. Employees who never recorded a sale (managers) - left = employees.
SELECT e.employee_id, e.full_name, e.job_title
FROM employees e
LEFT JOIN sales s ON e.employee_id = s.employee_id
WHERE s.sale_id IS NULL
ORDER BY e.employee_id;
