-- =====================================================================
-- 08_navigation_functions.sql | LAG() and LEAD()
-- LAG(col, n, default)  = value from n rows BEFORE the current row
-- LEAD(col, n, default) = value from n rows AFTER  the current row
-- =====================================================================

-- Q1. [Objective 3] Month-over-month revenue comparison with trend label.
WITH monthly AS (
    SELECT SUBSTR(CAST(sale_date AS VARCHAR(10)), 1, 7) AS sales_month,
           SUM(total_amount) AS revenue
    FROM sales GROUP BY 1
)
SELECT sales_month, revenue,
       LAG(revenue)  OVER (ORDER BY sales_month) AS previous_month,
       LEAD(revenue) OVER (ORDER BY sales_month) AS next_month,
       revenue - LAG(revenue) OVER (ORDER BY sales_month) AS change_amount,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY sales_month))
             / NULLIF(LAG(revenue) OVER (ORDER BY sales_month), 0), 1) AS change_pct,
       CASE
           WHEN LAG(revenue) OVER (ORDER BY sales_month) IS NULL THEN 'First month'
           WHEN revenue > LAG(revenue) OVER (ORDER BY sales_month) THEN 'INCREASE'
           WHEN revenue < LAG(revenue) OVER (ORDER BY sales_month) THEN 'DECREASE'
           ELSE 'NO CHANGE'
       END AS trend
FROM monthly
ORDER BY sales_month;

-- Q2. Consecutive transactions of the same customer: previous date & amount, and the difference.
-- (PostgreSQL days gap: sale_date - LAG(sale_date) OVER (...) ; MySQL: DATEDIFF(...))
SELECT customer_id, sale_id, sale_date, total_amount,
       LAG(sale_date)    OVER (PARTITION BY customer_id ORDER BY sale_date, sale_id) AS previous_purchase_date,
       LAG(total_amount) OVER (PARTITION BY customer_id ORDER BY sale_date, sale_id) AS previous_amount,
       total_amount - LAG(total_amount) OVER (PARTITION BY customer_id ORDER BY sale_date, sale_id) AS amount_change
FROM sales
WHERE customer_id IN (1, 2)
ORDER BY customer_id, sale_date, sale_id;

-- Q3. Upcoming payments: for every instalment, show the NEXT due date and amount of the same customer.
SELECT c.full_name, p.payment_id, p.due_date, p.amount, p.status,
       LEAD(p.due_date) OVER (PARTITION BY s.customer_id ORDER BY p.due_date) AS next_due_date,
       LEAD(p.amount)   OVER (PARTITION BY s.customer_id ORDER BY p.due_date) AS next_amount
FROM payments p
INNER JOIN sales     s ON p.sale_id     = s.sale_id
INNER JOIN customers c ON s.customer_id = c.customer_id
ORDER BY c.full_name, p.due_date
LIMIT 20;

-- Q4. The single NEXT pending payment per customer (ROW_NUMBER over pending instalments only).
WITH pending AS (
    SELECT c.full_name, p.due_date, p.amount,
           ROW_NUMBER() OVER (PARTITION BY s.customer_id ORDER BY p.due_date) AS rn
    FROM payments p
    INNER JOIN sales     s ON p.sale_id     = s.sale_id
    INNER JOIN customers c ON s.customer_id = c.customer_id
    WHERE p.status = 'PENDING'
)
SELECT full_name, due_date AS next_payment_due, amount FROM pending WHERE rn = 1 ORDER BY due_date;

-- Q5. Difference between consecutive sales records (chronological, whole company).
SELECT sale_id, sale_date, total_amount,
       LAG(total_amount, 1, 0) OVER (ORDER BY sale_date, sale_id) AS previous_sale,
       total_amount - LAG(total_amount, 1, 0) OVER (ORDER BY sale_date, sale_id) AS difference
FROM sales
ORDER BY sale_date, sale_id
LIMIT 15;
