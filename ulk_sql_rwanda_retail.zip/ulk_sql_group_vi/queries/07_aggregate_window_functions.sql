-- =====================================================================
-- 07_aggregate_window_functions.sql | SUM, AVG, MIN, MAX, COUNT with OVER()
-- Demonstrates PARTITION BY, ORDER BY, ROWS BETWEEN and RANGE BETWEEN
-- =====================================================================

-- Q1. Running sales total per branch: ROWS frame vs RANGE frame.
--  ROWS  = counts physical rows           -> total grows row by row
--  RANGE = includes ALL rows with the same ORDER BY value (same date = "peers")
-- Look at dates having 2+ sales: RANGE shows the same cumulative value for all of them.
SELECT branch_id, sale_date, sale_id, total_amount,
       SUM(total_amount) OVER (PARTITION BY branch_id
                               ORDER BY sale_date, sale_id
                               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)  AS running_total_rows,
       SUM(total_amount) OVER (PARTITION BY branch_id
                               ORDER BY sale_date
                               RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total_range
FROM sales
WHERE branch_id IN (1, 3)
ORDER BY branch_id, sale_date, sale_id;

-- Q2. Compare each transaction with its branch statistics (AVG, MIN, MAX, COUNT over a PARTITION).
SELECT branch_id, sale_id, total_amount,
       ROUND(AVG(total_amount) OVER (PARTITION BY branch_id), 0) AS branch_avg,
       MIN(total_amount) OVER (PARTITION BY branch_id)           AS branch_min,
       MAX(total_amount) OVER (PARTITION BY branch_id)           AS branch_max,
       COUNT(*)          OVER (PARTITION BY branch_id)           AS branch_txn_count,
       ROUND(total_amount - AVG(total_amount) OVER (PARTITION BY branch_id), 0) AS diff_from_avg,
       CASE WHEN total_amount > AVG(total_amount) OVER (PARTITION BY branch_id)
            THEN 'Above average' ELSE 'At/below average' END AS vs_avg
FROM sales
ORDER BY branch_id, sale_id
LIMIT 20;

-- Q3. [Objectives 2 & 5] Monthly revenue: cumulative total, 3-month moving average, best/worst month.
WITH monthly AS (
    SELECT SUBSTR(CAST(sale_date AS VARCHAR(10)), 1, 7) AS sales_month,
           SUM(total_amount) AS revenue
    FROM sales
    GROUP BY 1
)
SELECT sales_month, revenue,
       SUM(revenue) OVER (ORDER BY sales_month
                          ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)  AS cumulative_revenue,
       ROUND(AVG(revenue) OVER (ORDER BY sales_month
                          ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 0)      AS moving_avg_3m,
       COUNT(*) OVER (ORDER BY sales_month
                          ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)          AS months_in_window,
       MAX(revenue) OVER ()  AS best_month_revenue,
       MIN(revenue) OVER ()  AS worst_month_revenue
FROM monthly
ORDER BY sales_month;

-- Q4. Cumulative revenue per REGION by month (PARTITION BY + ORDER BY + RANGE frame).
WITH regional AS (
    SELECT r.region_name,
           SUBSTR(CAST(s.sale_date AS VARCHAR(10)), 1, 7) AS sales_month,
           SUM(s.total_amount) AS revenue
    FROM sales s
    INNER JOIN branches b ON s.branch_id = b.branch_id
    INNER JOIN regions  r ON b.region_id = r.region_id
    GROUP BY r.region_name, SUBSTR(CAST(s.sale_date AS VARCHAR(10)), 1, 7)
)
SELECT region_name, sales_month, revenue,
       SUM(revenue) OVER (PARTITION BY region_name ORDER BY sales_month
                          RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_region_revenue
FROM regional
ORDER BY region_name, sales_month;
