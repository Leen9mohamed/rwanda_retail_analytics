-- =====================================================================
-- 06_ranking_functions.sql | ROW_NUMBER, RANK, DENSE_RANK, PERCENT_RANK
-- =====================================================================

-- Q1. [Objective 1] Top 5 products in EACH region using RANK().
WITH product_region AS (
    SELECT r.region_name, p.product_name, SUM(s.total_amount) AS revenue
    FROM sales s
    INNER JOIN products p ON s.product_id = p.product_id
    INNER JOIN branches b ON s.branch_id  = b.branch_id
    INNER JOIN regions  r ON b.region_id  = r.region_id
    GROUP BY r.region_name, p.product_name
), ranked AS (
    SELECT region_name, product_name, revenue,
           RANK() OVER (PARTITION BY region_name ORDER BY revenue DESC) AS rnk
    FROM product_region
)
SELECT * FROM ranked WHERE rnk <= 5 ORDER BY region_name, rnk;

-- Q2. Difference between ROW_NUMBER, RANK and DENSE_RANK + PERCENT_RANK.
-- Products ordered by NUMBER OF TRANSACTIONS; ties make the 3 functions behave differently:
--   ROW_NUMBER : unique 1,2,3,4...      (ties broken arbitrarily)
--   RANK       : ties share a rank, then GAPS appear (1,2,2,4)
--   DENSE_RANK : ties share a rank, NO gaps          (1,2,2,3)
--   PERCENT_RANK: (rank-1)/(rows-1), relative position 0..1
WITH product_activity AS (
    SELECT p.product_name, COUNT(*) AS transactions
    FROM sales s INNER JOIN products p ON s.product_id = p.product_id
    GROUP BY p.product_name
)
SELECT product_name, transactions,
       ROW_NUMBER()  OVER (ORDER BY transactions DESC) AS row_num,
       RANK()        OVER (ORDER BY transactions DESC) AS rank_no,
       DENSE_RANK()  OVER (ORDER BY transactions DESC) AS dense_rank_no,
       ROUND(CAST(PERCENT_RANK() OVER (ORDER BY transactions DESC) AS NUMERIC), 3) AS pct_rank
FROM product_activity
ORDER BY transactions DESC, product_name;

-- Q3. Top 3 customers in EACH region (by total spending).
WITH customer_spend AS (
    SELECT c.customer_id, c.full_name, r.region_name, SUM(s.total_amount) AS total_spent
    FROM customers c
    INNER JOIN regions r ON c.region_id   = r.region_id
    INNER JOIN sales   s ON c.customer_id = s.customer_id
    GROUP BY c.customer_id, c.full_name, r.region_name
), ranked AS (
    SELECT *, DENSE_RANK() OVER (PARTITION BY region_name ORDER BY total_spent DESC) AS rank_in_region
    FROM customer_spend
)
SELECT region_name, rank_in_region, full_name, total_spent
FROM ranked WHERE rank_in_region <= 3
ORDER BY region_name, rank_in_region;

-- Q4. Rank sales employees by revenue: company-wide AND inside their own branch.
WITH emp_sales AS (
    SELECT e.employee_id, e.full_name, b.branch_name,
           COALESCE(SUM(s.total_amount), 0) AS revenue
    FROM employees e
    INNER JOIN branches b ON e.branch_id = b.branch_id
    LEFT  JOIN sales    s ON e.employee_id = s.employee_id
    WHERE e.job_title = 'Sales Representative'
    GROUP BY e.employee_id, e.full_name, b.branch_name
)
SELECT full_name, branch_name, revenue,
       RANK() OVER (ORDER BY revenue DESC)                          AS company_rank,
       RANK() OVER (PARTITION BY branch_name ORDER BY revenue DESC) AS branch_rank,
       ROUND(CAST(PERCENT_RANK() OVER (ORDER BY revenue DESC) AS NUMERIC), 3) AS pct_rank
FROM emp_sales
ORDER BY company_rank;

-- Q5. Highest-performing branch (rank 1 by revenue). Full ranking shown first, then only rank 1.
WITH branch_rev AS (
    SELECT b.branch_name, r.region_name, SUM(s.total_amount) AS revenue
    FROM sales s
    INNER JOIN branches b ON s.branch_id = b.branch_id
    INNER JOIN regions  r ON b.region_id = r.region_id
    GROUP BY b.branch_name, r.region_name
), ranked AS (
    SELECT *, RANK() OVER (ORDER BY revenue DESC) AS branch_rank FROM branch_rev
)
SELECT * FROM ranked ORDER BY branch_rank;

WITH branch_rev AS (
    SELECT b.branch_name, SUM(s.total_amount) AS revenue
    FROM sales s INNER JOIN branches b ON s.branch_id = b.branch_id
    GROUP BY b.branch_name
), ranked AS (
    SELECT *, RANK() OVER (ORDER BY revenue DESC) AS branch_rank FROM branch_rev
)
SELECT branch_name, revenue FROM ranked WHERE branch_rank = 1;
