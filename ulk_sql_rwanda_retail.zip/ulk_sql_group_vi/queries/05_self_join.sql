-- =====================================================================
-- 05_self_join.sql  |  SELF JOIN: a table joined to itself (use two different aliases)
-- =====================================================================

-- Q1. Employee -> Manager hierarchy (employees.manager_id references employees.employee_id).
-- LEFT JOIN keeps the top manager, who has no manager.
SELECT e.employee_id,
       e.full_name  AS employee,
       e.job_title,
       m.full_name  AS manager,
       m.job_title  AS manager_title
FROM employees e
LEFT JOIN employees m ON e.manager_id = m.employee_id
ORDER BY e.employee_id;

-- Q2. Pairs of customers in the SAME region (c1.customer_id < c2.customer_id avoids duplicates and self-pairs).
SELECT r.region_name,
       c1.full_name AS customer_1,
       c2.full_name AS customer_2
FROM customers c1
INNER JOIN customers c2 ON c1.region_id = c2.region_id AND c1.customer_id < c2.customer_id
INNER JOIN regions   r  ON c1.region_id = r.region_id
ORDER BY r.region_name, c1.customer_id, c2.customer_id;

-- Q3. Pairs of colleagues working in the SAME branch (self join on branch_id).
SELECT b.branch_name, e1.full_name AS colleague_1, e2.full_name AS colleague_2
FROM employees e1
INNER JOIN employees e2 ON e1.branch_id = e2.branch_id AND e1.employee_id < e2.employee_id
INNER JOIN branches  b  ON e1.branch_id = b.branch_id
ORDER BY b.branch_name, e1.employee_id;
