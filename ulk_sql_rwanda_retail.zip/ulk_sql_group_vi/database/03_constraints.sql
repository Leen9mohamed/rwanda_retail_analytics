-- =====================================================================
-- File    : 03_constraints.sql
-- Purpose : Extra business-rule constraints and indexes (PostgreSQL syntax)
-- Run AFTER 01_create_tables.sql and 02_insert_data.sql
-- =====================================================================

ALTER TABLE products  ADD CONSTRAINT chk_price    CHECK (unit_price > 0);
ALTER TABLE employees ADD CONSTRAINT chk_salary   CHECK (salary > 0);
ALTER TABLE sales     ADD CONSTRAINT chk_quantity CHECK (quantity > 0);
ALTER TABLE sales     ADD CONSTRAINT chk_total    CHECK (total_amount > 0);
ALTER TABLE payments  ADD CONSTRAINT chk_status   CHECK (status IN ('PAID','PENDING'));
ALTER TABLE customers ADD CONSTRAINT uq_email     UNIQUE (email);

-- Indexes on foreign keys / frequently filtered columns (speed up JOINs and window sorts)
CREATE INDEX idx_sales_date     ON sales(sale_date);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_sales_product  ON sales(product_id);
CREATE INDEX idx_sales_branch   ON sales(branch_id);
CREATE INDEX idx_payments_sale  ON payments(sale_id);
