-- =====================================================================
-- ULK SQL Group Assignment VI  |  Project: SmartMart Rwanda Retail Analytics
-- File    : 01_create_tables.sql
-- Purpose : Create the 7 related tables (PostgreSQL 13+; also runs on SQLite 3.39+)
-- =====================================================================

DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS branches;
DROP TABLE IF EXISTS regions;

-- 1) REGIONS: geographic regions of Rwanda served by the company
CREATE TABLE regions (
    region_id    INT          PRIMARY KEY,
    region_name  VARCHAR(50)  NOT NULL UNIQUE
);

-- 2) BRANCHES: each branch belongs to exactly one region (1 region -> many branches)
CREATE TABLE branches (
    branch_id    INT          PRIMARY KEY,
    branch_name  VARCHAR(80)  NOT NULL,
    region_id    INT          NOT NULL REFERENCES regions(region_id),
    opened_date  DATE         NOT NULL
);

-- 3) EMPLOYEES: works in one branch; manager_id is a SELF-REFERENCE (used by SELF JOIN)
CREATE TABLE employees (
    employee_id  INT           PRIMARY KEY,
    full_name    VARCHAR(80)   NOT NULL,
    job_title    VARCHAR(50)   NOT NULL,
    branch_id    INT           NOT NULL REFERENCES branches(branch_id),
    manager_id   INT           NULL REFERENCES employees(employee_id),
    hire_date    DATE          NOT NULL,
    salary       NUMERIC(12,2) NOT NULL
);

-- 4) CUSTOMERS: each customer lives in one region
CREATE TABLE customers (
    customer_id  INT          PRIMARY KEY,
    full_name    VARCHAR(80)  NOT NULL,
    email        VARCHAR(100),
    region_id    INT          NOT NULL REFERENCES regions(region_id),
    join_date    DATE         NOT NULL
);

-- 5) PRODUCTS: catalogue of items sold
CREATE TABLE products (
    product_id    INT           PRIMARY KEY,
    product_name  VARCHAR(80)   NOT NULL,
    category      VARCHAR(40)   NOT NULL,
    unit_price    NUMERIC(12,2) NOT NULL
);

-- 6) SALES: one row per transaction. customer_id is NULLABLE (walk-in customers)
CREATE TABLE sales (
    sale_id       INT           PRIMARY KEY,
    sale_date     DATE          NOT NULL,
    customer_id   INT           NULL REFERENCES customers(customer_id),
    product_id    INT           NOT NULL REFERENCES products(product_id),
    branch_id     INT           NOT NULL REFERENCES branches(branch_id),
    employee_id   INT           NOT NULL REFERENCES employees(employee_id),
    quantity      INT           NOT NULL,
    total_amount  NUMERIC(12,2) NOT NULL
);

-- 7) PAYMENTS: instalment schedule for large sales (used by LEAD() for upcoming payments)
CREATE TABLE payments (
    payment_id  INT           PRIMARY KEY,
    sale_id     INT           NOT NULL REFERENCES sales(sale_id),
    due_date    DATE          NOT NULL,
    amount      NUMERIC(12,2) NOT NULL,
    status      VARCHAR(10)   NOT NULL
);
